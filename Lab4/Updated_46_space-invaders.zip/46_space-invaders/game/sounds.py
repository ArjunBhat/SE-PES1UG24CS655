import array
import math
import random

import pygame

SAMPLE_RATE = 44100
MASTER_VOLUME = 0.35


class SoundManager:
    """Generates simple sound effects in memory and plays them.

    If the mixer can't be initialised (no audio device, unsupported format, etc.)
    the manager disables itself and play() silently does nothing.
    """

    def __init__(self):
        self.enabled = False
        self._sounds = {}
        self._rate = SAMPLE_RATE
        self._channels = 2

        try:
            self._init_mixer()
            self._sounds = {
                "fire": self._make_sound(self._fire_samples()),
                "enemy_destroyed": self._make_sound(self._explosion_samples()),
                "game_over": self._make_sound(self._game_over_samples()),
            }
            self.enabled = True
        except Exception as exc:  # pygame.error, missing mixer module, etc.
            print(f"Sound disabled: {exc}")
            self._sounds = {}
            self.enabled = False

    def play(self, name):
        if not self.enabled:
            return
        sound = self._sounds.get(name)
        if sound is None:
            return
        try:
            sound.play()
        except pygame.error:
            pass  # never let audio problems crash the game

    # ---- mixer setup -------------------------------------------------------

    def _init_mixer(self):
        info = pygame.mixer.get_init()
        # We build 16-bit signed samples, so make sure the mixer uses that format.
        if info is None or info[1] != -16:
            pygame.mixer.quit()
            pygame.mixer.init(SAMPLE_RATE, -16, 2, 512)
            info = pygame.mixer.get_init()
        if info is None or info[1] != -16:
            raise pygame.error("mixer could not be initialised with 16-bit audio")
        self._rate, _, self._channels = info

    def _make_sound(self, samples):
        """Convert floats in [-1, 1] to 16-bit PCM, duplicated across channels."""
        pcm = array.array("h")
        for s in samples:
            value = int(max(-1.0, min(1.0, s)) * MASTER_VOLUME * 32767)
            for _ in range(self._channels):
                pcm.append(value)
        return pygame.mixer.Sound(buffer=pcm.tobytes())

    # ---- sound synthesis ---------------------------------------------------

    def _fire_samples(self):
        """Short 'pew': square wave sweeping from high to low pitch."""
        duration = 0.12
        count = int(self._rate * duration)
        samples = []
        phase = 0.0
        for i in range(count):
            t = i / count
            freq = 900 - 600 * t
            phase += 2 * math.pi * freq / self._rate
            wave = 1.0 if math.sin(phase) >= 0 else -1.0
            samples.append(wave * 0.5 * (1.0 - t))
        return samples

    def _explosion_samples(self):
        """Noise burst with a fast decay, lightly smoothed so it rumbles."""
        duration = 0.3
        count = int(self._rate * duration)
        samples = []
        prev = 0.0
        for i in range(count):
            t = i / count
            noise = random.uniform(-1.0, 1.0)
            prev = 0.6 * prev + 0.4 * noise
            samples.append(prev * math.exp(-5 * t))
        return samples

    def _game_over_samples(self):
        """Four descending notes, the last one held longer."""
        notes = [(440, 0.2), (370, 0.2), (311, 0.2), (220, 0.5)]
        samples = []
        for freq, duration in notes:
            count = int(self._rate * duration)
            for i in range(count):
                t = i / count
                wave = 1.0 if math.sin(2 * math.pi * freq * i / self._rate) >= 0 else -1.0
                samples.append(wave * 0.4 * (1.0 - 0.6 * t))
        return samples